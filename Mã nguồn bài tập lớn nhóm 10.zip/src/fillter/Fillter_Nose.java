package fillter;

import org.opencv.objdetect.CascadeClassifier;

public class Fillter_Nose extends Fillter {
    protected CascadeClassifier noseDectect = new CascadeClassifier();

}
