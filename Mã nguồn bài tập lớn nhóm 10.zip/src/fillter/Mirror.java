package fillter;

import org.opencv.core.Mat;

public class Mirror extends Fillter{
    @Override
    public void filtering(Mat src, Mat des) {
        // TODO Auto-generated method stub
        
    }
}
