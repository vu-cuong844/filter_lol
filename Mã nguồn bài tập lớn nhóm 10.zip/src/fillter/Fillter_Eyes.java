package fillter;

import org.opencv.objdetect.CascadeClassifier;

public class Fillter_Eyes extends Fillter {
    protected CascadeClassifier eyesDetect = new CascadeClassifier();

}
