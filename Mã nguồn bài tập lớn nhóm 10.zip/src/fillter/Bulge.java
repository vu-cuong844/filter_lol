package fillter;

import org.opencv.core.Mat;

public class Bulge extends Fillter {
    @Override
    public void filtering(Mat src, Mat des) {
        
    }
}
