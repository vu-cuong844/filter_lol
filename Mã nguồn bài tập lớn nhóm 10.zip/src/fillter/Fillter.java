package fillter;


import org.opencv.core.Mat;
import org.opencv.core.MatOfRect;

public class Fillter {
    protected static MatOfRect faceDetections = new MatOfRect();
    public void filtering( Mat src, Mat des){}
    public void setFilter(){}
}
