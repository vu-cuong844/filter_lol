package fillter;

import org.opencv.objdetect.CascadeClassifier;

public class Fillter_Mouth extends Fillter {
    protected CascadeClassifier mouthDetect = new CascadeClassifier();
    
}
